import streamlit as st
import requests
from core.engine import NabdCognitiveEngine, SimpleVectorStore

st.set_page_config(
    page_title="Nabd Cognitive Reasoning Dashboard",
    page_icon="🏥",
    layout="wide"
)

# Initialize Engine for Local Evaluation
@st.cache_resource
def load_engine():
    vector_store = SimpleVectorStore()
    return NabdCognitiveEngine(vector_store=vector_store)

engine = load_engine()

st.title("🏥 Nabd Clinical Reasoning & Cognitive Bias Evaluator")
st.markdown("An AI-driven diagnostic engine evaluating clinical decision steps and detecting cognitive biases.")

st.sidebar.header("📋 Case Input Configuration")
case_id = st.sidebar.text_input("Case ID", value="CASE_CLINICAL_101")

required_labs_input = st.sidebar.text_area(
    "Required Laboratory Investigations (comma separated)",
    value="12-lead ECG, Troponin I/T"
)

required_findings_input = st.sidebar.text_area(
    "Required Physical Findings (comma separated)",
    value="chest pain"
)

differential_input = st.sidebar.text_area(
    "Differential Diagnoses (comma separated)",
    value="STEMI, Acute Coronary Syndrome"
)

st.subheader("📝 Student Clinical Reasoning Input")
student_reasoning = st.text_area(
    "Enter student case assessment, findings, and preliminary diagnosis:",
    height=150,
    value="The patient presents with severe retrosternal chest pain. The diagnosis is STEMI."
)

if st.button("Evaluate Reasoning 🚀", type="primary"):
    if not student_reasoning.strip():
        st.error("Please enter student reasoning before evaluating.")
    else:
        labs = [x.strip() for x in required_labs_input.split(",") if x.strip()]
        findings = [x.strip() for x in required_findings_input.split(",") if x.strip()]
        differentials = [x.strip() for x in differential_input.split(",") if x.strip()]

        report = engine.analyze_reasoning(
            case_id=case_id,
            student_input=student_reasoning,
            required_labs=labs,
            required_findings=findings,
            differential_diagnoses=differentials
        )

        st.markdown("---")
        col1, col2, col3 = st.columns(3)
        col1.metric("Cognitive Score", f"{report.overall_cognitive_score}%")
        col2.metric("Safety Status", report.clinical_safety_level)
        col3.metric("Covered Symptoms", f"{len(report.covered_symptoms)} / {len(findings)}")

        st.subheader("⚠️ Cognitive Bias Analysis")
        for bias in report.detected_biases:
            if bias.detected:
                st.error(f"**Detected Bias: {bias.bias_type} (Severity: {bias.severity.value})**")
                st.write(f"**Evidence:** {bias.evidence_found}")
                st.write(f"**Clinical Risk:** {bias.clinical_risk}")
                st.info(f"**Remediation Advice:** {bias.remediation_advice}")
            else:
                st.success(f"**No {bias.bias_type} Detected.** Good clinical approach!")

        st.subheader("🔍 Clinical Guidance & Missing Investigations")
        if report.missed_critical_investigations:
            st.warning(f"**Missed Labs:** {', '.join(report.missed_critical_investigations)}")
        else:
            st.success("All critical investigations were addressed.")

        if report.retrieved_guidelines:
            st.subheader("📚 Matched Guidelines")
            for guide in report.retrieved_guidelines:
                st.write(f"- {guide}")
