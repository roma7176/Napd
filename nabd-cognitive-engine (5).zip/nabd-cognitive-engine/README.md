# 🏥 Nabd Cognitive Engine

**Nabd Cognitive Engine** is an AI-driven clinical reasoning evaluation framework designed to assess medical diagnostic steps, calculate performance metrics, and detect cognitive biases in medical education workflows.

---

## 🔑 Key Features
- **Cognitive Bias Detection**: Detects clinical reasoning failures like Premature Closure.
- **Safety Verification**: Highlights unordered or missed critical medical investigations.
- **Semantic Knowledge Retrieval**: Advanced RAG retrieval for medical guidelines matching.
- **FastAPI Endpoint**: RESTful web interface for integration.
- **Streamlit UI**: Interactive GUI dashboard for clinical educators.
- **Dockerized**: Ready for containerized deployment.
- **Continuous Integration**: Automated PyTest test execution via GitHub Actions.

---

## 🛠️ Project Architecture

```text
nabd-cognitive-engine/
├── .github/
│   └── workflows/
│       └── ci.yml        # GitHub Actions CI Pipeline
├── core/
│   ├── __init__.py
│   └── engine.py         # Advanced RAG & Cognitive Core
├── api/
│   └── app.py            # FastAPI Service Endpoint
├── tests/
│   ├── test_engine.py    # Core Engine Tests
│   └── test_api.py       # API Integration Tests
├── app_ui.py             # Streamlit Interactive Dashboard
├── Dockerfile            # Container Configuration
├── .dockerignore         # Docker Exclusions
├── requirements.txt      # Project Dependencies
├── RELEASE_NOTES.md      # Production Release Documentation
└── README.md             # Project Documentation
```

---

## 🚀 Quick Execution Guide

### Local Execution
```bash
pip install -r requirements.txt
streamlit run app_ui.py
```

### Container Execution
```bash
docker build -t nabd-cognitive-engine .
docker run -p 8501:8501 nabd-cognitive-engine
```
