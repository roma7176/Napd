import json
import random
import re
import time
from datetime import datetime
import ai_engine

TOTAL_TESTS = 15
MAX_REQUESTS_PER_MINUTE = 5
RETRY_BUFFER_SECONDS = 3
CONNECTION_RETRY_SECONDS = 10

TESTS = [
    {"id":1,"function":"analyze","input":"The patient has fever and shortness of breath. I think this may be pneumonia."},
    {"id":2,"function":"analyze","input":"Pneumonia is the most likely diagnosis because of fever and lobar consolidation."},
    {"id":3,"function":"analyze","input":"Pulmonary embolism is possible because of acute dyspnea and tachycardia."},
    {"id":4,"function":"analyze","input":"I am not certain about the diagnosis and need more information."},
    {"id":5,"function":"analyze","input":"The WBC is 18.2 and CRP is 142. I interpret these findings as evidence of inflammation."},
    {"id":6,"function":"analyze","input":"The chest X-ray shows dense right lower-lobe lobar consolidation with air bronchograms."},
    {"id":7,"function":"analyze","input":"Pneumonia is my working diagnosis, but pulmonary embolism remains possible."},

    {"id":8,"function":"generate_defense","input":{
        "working_diagnosis":{
            "diagnosis":"Pneumonia",
            "evidence":["Fever","Lobar consolidation"]
        },
        "differential_diagnoses":[]
    }},

    {"id":9,"function":"generate_defense","input":{
        "working_diagnosis":{
            "diagnosis":"Pneumonia",
            "evidence":["Fever"]
        },
        "differential_diagnoses":[
            {
                "diagnosis":"Pulmonary Embolism",
                "supporting_evidence":["Dyspnea"],
                "opposing_evidence":["Fever"]
            }
        ]
    }},

    {"id":10,"function":"generate_defense","input":{
        "working_diagnosis":{
            "diagnosis":"Pneumonia",
            "evidence":["Shortness of breath"]
        },
        "differential_diagnoses":[
            {
                "diagnosis":"Pulmonary Embolism",
                "supporting_evidence":["Tachycardia"],
                "opposing_evidence":[]
            }
        ]
    }},

    {"id":11,"function":"evaluate_answer","input":{
        "question":"Why did you consider pneumonia?",
        "student_answer":"Because the patient has fever.",
        "parsed_reasoning":{
            "working_diagnosis":{
                "diagnosis":"Pneumonia",
                "evidence":["Fever"]
            }
        }
    }},

    {"id":12,"function":"evaluate_answer","input":{
        "question":"Why is pulmonary embolism possible?",
        "student_answer":"Because of acute dyspnea.",
        "parsed_reasoning":{
            "working_diagnosis":{
                "diagnosis":"Pneumonia",
                "evidence":["Fever"]
            },
            "differential_diagnoses":[
                {
                    "diagnosis":"Pulmonary Embolism",
                    "supporting_evidence":["Acute dyspnea"],
                    "opposing_evidence":[]
                }
            ]
        }
    }},

    {"id":13,"function":"detect_bias","input":{
        "working_diagnosis":{
            "diagnosis":"Pneumonia",
            "evidence":["Fever"]
        },
        "differential_diagnoses":[
            {
                "diagnosis":"Pulmonary Embolism",
                "supporting_evidence":["Dyspnea"],
                "opposing_evidence":[]
            }
        ],
        "reasoning_steps":[
            "Considered pneumonia",
            "Considered pulmonary embolism"
        ]
    }},

    {"id":14,"function":"detect_bias","input":{
        "working_diagnosis":{
            "diagnosis":"Pneumonia",
            "evidence":["Fever"]
        },
        "differential_diagnoses":[],
        "reasoning_steps":[
            "Pneumonia is the diagnosis and no alternatives are needed"
        ]
    }},

    {"id":15,"function":"detect_bias","input":{
        "working_diagnosis":{
            "diagnosis":None,
            "evidence":[]
        },
        "differential_diagnoses":[],
        "reasoning_steps":[
            "I cannot determine the diagnosis"
        ]
    }}
]

def get_function(names):
    for name in names:
        function = getattr(ai_engine, name, None)
        if callable(function):
            return function
    return None

def run_test(test):
    function_name = test["function"]
    data = test["input"]

    if function_name == "analyze":
        function = get_function([
            "analyze_thinkaloud",
            "analyze_think_aloud",
            "analyze_thinkaloud_safe",
            "analyze_think_aloud_safe"
        ])

        if function is None:
            raise AttributeError(
                "No Think-Aloud analysis function found in ai_engine.py"
            )

        return function(data)

    if function_name == "generate_defense":
        function = get_function([
            "generate_defense",
            "generate_defense_safe"
        ])

        if function is None:
            raise AttributeError(
                "generate_defense function not found in ai_engine.py"
            )

        return function(data)

    if function_name == "evaluate_answer":
        function = get_function([
            "evaluate_answer",
            "evaluate_answer_safe"
        ])

        if function is None:
            raise AttributeError(
                "evaluate_answer function not found in ai_engine.py"
            )

        return function(
            data["question"],
            data["student_answer"],
            data["parsed_reasoning"]
        )

    if function_name == "detect_bias":
        function = get_function([
            "detect_bias",
            "detect_bias_safe"
        ])

        if function is None:
            raise AttributeError(
                "detect_bias function not found in ai_engine.py"
            )

        return function(data)

    raise ValueError(
        f"Unknown function: {function_name}"
    )

def is_quota_error(error):
    text = str(error).lower()

    return (
        "429" in text
        or "resource_exhausted" in text
        or "quota exceeded" in text
        or "generaterequestsperminuteperprojectpermodel" in text
    )

def is_connection_error(error):
    text = str(error).lower()

    return (
        "connecterror" in text
        or "getaddrinfo failed" in text
        or "connection error" in text
        or "connection refused" in text
        or "connection reset" in text
        or "timeout" in text
        or "timed out" in text
    )

def get_retry_seconds(error):
    text = str(error)

    match = re.search(
        r"retry in ([0-9]+(?:\.[0-9]+)?)s",
        text,
        re.IGNORECASE
    )

    if match:
        return max(
            1,
            int(float(match.group(1))) + RETRY_BUFFER_SECONDS
        )

    match = re.search(
        r"retryDelay.*?([0-9]+)s",
        text,
        re.IGNORECASE
    )

    if match:
        return max(
            1,
            int(match.group(1)) + RETRY_BUFFER_SECONDS
        )

    return 63

def wait_for_quota(error=None):
    if error is not None:
        seconds = get_retry_seconds(error)
    else:
        seconds = 63

    print()
    print(
        f"QUOTA LIMIT - waiting {seconds} seconds..."
    )

    time.sleep(seconds)

def save_result(results, run_id, filename):
    passed = sum(
        1
        for item in results
        if item["status"] == "PASS"
    )

    failed = len(results) - passed

    output = {
        "task": "NABD Task 13 - Stress Testing",
        "run_id": run_id,
        "created_at": datetime.now().isoformat(),
        "total_tests": len(results),
        "passed": passed,
        "failed": failed,
        "results": results
    }

    with open(
        filename,
        "w",
        encoding="utf-8"
    ) as file:
        json.dump(
            output,
            file,
            ensure_ascii=False,
            indent=2
        )

def main():
    print("=" * 70)
    print("NABD - TASK 13")
    print("STRESS TESTING")
    print("=" * 70)

    run_id = (
        datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        + "_"
        + str(random.randint(1000, 9999))
    )

    filename = (
        "task13_stress_testing_"
        + run_id
        + ".json"
    )

    print()
    print("Run ID:", run_id)
    print("Testing 15 integration scenarios...")
    print("Using functions from ai_engine.py.")
    print("Rate limit protection: 5 requests per minute.")

    results = []
    request_times = []

    for test in TESTS:
        print()
        print(
            f"TEST {test['id']}/{TOTAL_TESTS} - "
            f"{test['function']}"
        )

        completed = False

        while not completed:
            now = time.time()

            request_times = [
                timestamp
                for timestamp in request_times
                if now - timestamp < 60
            ]

            if len(request_times) >= MAX_REQUESTS_PER_MINUTE:
                wait_seconds = (
                    int(
                        60 - (now - request_times[0])
                    )
                    + RETRY_BUFFER_SECONDS
                )

                print()
                print(
                    f"RATE LIMIT PROTECTION - "
                    f"waiting {wait_seconds} seconds..."
                )

                time.sleep(wait_seconds)
                continue

            try:
                request_times.append(time.time())

                response = run_test(test)

                if response is None:
                    raise ValueError(
                        "Function returned empty response."
                    )

                print("STATUS: PASS")

                results.append(
                    {
                        "test_id": test["id"],
                        "function": test["function"],
                        "status": "PASS",
                        "response": response,
                        "issues": []
                    }
                )

                completed = True

            except Exception as e:

                if is_quota_error(e):
                    print()
                    print("QUOTA ERROR DETECTED")
                    print(
                        "The current test will be retried."
                    )

                    wait_for_quota(e)
                    continue

                if is_connection_error(e):
                    print()
                    print("CONNECTION ERROR DETECTED")
                    print(
                        f"Retrying in "
                        f"{CONNECTION_RETRY_SECONDS} seconds..."
                    )

                    time.sleep(
                        CONNECTION_RETRY_SECONDS
                    )
                    continue

                print("STATUS: FAIL")
                print(
                    "Error:",
                    type(e).__name__,
                    str(e)
                )

                results.append(
                    {
                        "test_id": test["id"],
                        "function": test["function"],
                        "status": "FAIL",
                        "response": None,
                        "issues": [
                            f"{type(e).__name__}: {str(e)}"
                        ]
                    }
                )

                completed = True

    save_result(
        results,
        run_id,
        filename
    )

    passed = sum(
        1
        for item in results
        if item["status"] == "PASS"
    )

    failed = len(results) - passed

    print()
    print("=" * 70)
    print("TASK 13 SUMMARY")
    print("=" * 70)

    print("Total:", len(results))
    print("Passed:", passed)
    print("Failed:", failed)

    if failed == 0:
        print()
        print("TASK 13 STATUS: PASSED")
    else:
        print()
        print("TASK 13 STATUS: NEEDS IMPROVEMENT")

    print()
    print("New result file:")
    print(filename)

if __name__ == "__main__":
    main()