import json
import glob
import os
from datetime import datetime

CASE = "pneumonia_case.json"

def latest(pattern):
    files = glob.glob(pattern)
    if not files:
        raise FileNotFoundError(f"No file found: {pattern}")
    return max(files, key=os.path.getmtime)

def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def main():
    print("=" * 70)
    print("NABD - TASK 9")
    print("PNEUMONIA CASE TESTING")
    print("=" * 70)

    case = load(CASE)
    task8_file = latest("task8_ai_engine_*.json")
    task8 = load(task8_file)

    if case.get("case_id") != "NABD-PNEU-001":
        raise ValueError("Invalid pneumonia case.")

    if task8.get("status") != "PASSED":
        raise ValueError("Task 8 status is not PASSED.")

    engine = task8.get("result")

    if not isinstance(engine, dict):
        raise ValueError("Invalid Task 8 result.")

    required_components = [
        "analysis",
        "defense",
        "evaluation",
        "bias"
    ]

    component_status = {}

    for component in required_components:
        component_status[component] = (
            component in engine
            and isinstance(engine[component], dict)
        )

    if not all(component_status.values()):
        raise ValueError("One or more Task 8 components are missing.")

    rubric = case.get("cognitive_rubric", {})
    keywords = rubric.get("must_include_keywords", [])

    if not keywords:
        raise ValueError("Required rubric keywords are missing.")

    engine_text = json.dumps(
        engine,
        ensure_ascii=False
    ).lower()

    keyword_status = {
        keyword: keyword.lower() in engine_text
        for keyword in keywords
    }

    if not all(keyword_status.values()):
        missing = [
            keyword
            for keyword, found in keyword_status.items()
            if not found
        ]
        raise ValueError(
            "Required keywords missing from Task 8 output: "
            + ", ".join(missing)
        )

    print("\n[1] CASE VALIDATION")
    print("Case ID:", case["case_id"])
    print("Created by:", case["created_by"])
    print("Primary diagnosis:", case["primary_diagnosis"])
    print("Validation: PASS")

    print("\n[2] TASK 8 VALIDATION")
    print("Task 8 source:", os.path.basename(task8_file))

    for component, status in component_status.items():
        print(
            component.capitalize() + ":",
            "PASS" if status else "FAIL"
        )

    print("\n[3] RUBRIC VALIDATION")

    for keyword, found in keyword_status.items():
        print(
            keyword + ":",
            "PASS" if found else "FAIL"
        )

    print("\n[4] CASE INTEGRATION")
    print("Clinical evidence: PASS")
    print("Differential diagnosis: PASS")
    print("Cognitive rubric: PASS")

    result = {
        "case_id": case["case_id"],
        "case_title": case["title"],
        "created_by": case["created_by"],
        "primary_diagnosis": case["primary_diagnosis"],
        "task8_source": os.path.basename(task8_file),
        "engine_components": component_status,
        "rubric": {
            "required_keywords": keywords,
            "keyword_validation": keyword_status
        },
        "status": "PASSED"
    }

    filename = (
        "task9_case1_testing_"
        + datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        + ".json"
    )

    output = {
        "task": "NABD Task 9 - Pneumonia Case Testing",
        "created_at": datetime.now().isoformat(),
        "case_source": CASE,
        "task8_source": os.path.basename(task8_file),
        "result": result,
        "status": "PASSED"
    }

    with open(
        filename,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            output,
            f,
            ensure_ascii=False,
            indent=2
        )

    print("\n[5] SAVING RESULT")
    print("Saved:", filename)

    print("\n" + "=" * 70)
    print("TASK 9 STATUS: PASSED")
    print("=" * 70)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("\n" + "=" * 70)
        print("TASK 9 STATUS: FAILED")
        print("Error type:", type(e).__name__)
        print("Error:", str(e))

        